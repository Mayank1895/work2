import sounddevice as sd
from scipy.io.wavfile import write
from resemblyzer import VoiceEncoder, preprocess_wav
from pathlib import Path
import numpy as np
import whisper
import sys

# -----------------------------
# 1️⃣ Record audio
# -----------------------------
def record_audio(filename, seconds=4):
    fs = 16000
    print("🎤 Speak your command...")
    audio = sd.rec(int(seconds * fs), samplerate=fs, channels=1)
    sd.wait()
    write(filename, fs, audio)

record_audio("command.wav")

# -----------------------------
# 2️⃣ Speaker verification
# -----------------------------
saved_embedding = np.load("my_voice.npy")
encoder = VoiceEncoder()

wav = preprocess_wav(Path("command.wav"))
new_embedding = encoder.embed_utterance(wav)

similarity = np.dot(saved_embedding, new_embedding)
print(f"🔎 Voice similarity: {similarity:.2f}")

THRESHOLD = 0.70

if similarity < THRESHOLD:
    print("❌ Unauthorized voice. Command rejected.")
    sys.exit()

print("✅ Authorized voice")

# -----------------------------
# 3️⃣ Speech to text (Whisper)
# -----------------------------
model = whisper.load_model("base")
result = model.transcribe("command.wav")

text = result["text"].lower()
print("📝 You said:", text)

# -----------------------------
# 4️⃣ Command understanding
# -----------------------------
def understand_command(text):
    if "switch on" in text and "fan" in text:
        return "FAN_ON"
    elif "switch off" in text and "fan" in text:
        return "FAN_OFF"
    else:
        return "UNKNOWN"

# -----------------------------
# 5️⃣ Action execution
# -----------------------------
def execute_action(action):
    if action == "FAN_ON":
        print("🟢 Fan turned ON")
    elif action == "FAN_OFF":
        print("🔴 Fan turned OFF")
    else:
        print("⚠️ Command not recognized")

action = understand_command(text)
execute_action(action)
