import sounddevice as sd
from scipy.io.wavfile import write
from resemblyzer import VoiceEncoder, preprocess_wav
from pathlib import Path
import numpy as np

# Step 1: record audio
def record_audio(filename, seconds=6):
    fs = 16000
    print("🎤 Speak naturally for", seconds, "seconds...")
    audio = sd.rec(int(seconds * fs), samplerate=fs, channels=1)
    sd.wait()
    write(filename, fs, audio)
    print("✅ Audio saved as", filename)

# Record your voice
record_audio("my_voice.wav")

# Step 2: create voice fingerprint
encoder = VoiceEncoder()

wav = preprocess_wav(Path("my_voice.wav"))
embedding = encoder.embed_utterance(wav)

# Step 3: save fingerprint
np.save("my_voice.npy", embedding)

print("🔐 Voice enrollment completed!")
