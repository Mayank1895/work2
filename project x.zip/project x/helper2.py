#for verify before the main code
import sounddevice as sd
from scipy.io.wavfile import write

def record_audio(filename, seconds=4):
    fs = 16000
    print("🎤 Speak now for verification...")
    audio = sd.rec(int(seconds * fs), samplerate=fs, channels=1)
    sd.wait()
    write(filename, fs, audio)
    print("✅ Recorded", filename)

record_audio("command.wav")