import sounddevice as sd
from scipy.io.wavfile import write

# Step 1: record audio
def record_audio(filename, seconds=6):
    fs = 16000
    print("🎤 Speak naturally for", seconds, "seconds...")
    audio = sd.rec(int(seconds * fs), samplerate=fs, channels=1)
    sd.wait()
    write(filename, fs, audio)
    print("✅ Audio saved as", filename)

record_audio("my_voice.wav")
