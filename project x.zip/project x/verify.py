import sounddevice as sd
from scipy.io.wavfile import write
from resemblyzer import VoiceEncoder, preprocess_wav
from pathlib import Path
import numpy as np

# Record new voice
def record_audio(filename, seconds=4):
    fs = 16000
    print("🎤 Speak now for verification...")
    audio = sd.rec(int(seconds * fs), samplerate=fs, channels=1)
    sd.wait()
    write(filename, fs, audio)

record_audio("command.wav")

# Load enrolled voice fingerprint
saved_embedding = np.load("my_voice.npy")

# Create encoder
encoder = VoiceEncoder()

# Process new voice
wav = preprocess_wav(Path("command.wav"))
new_embedding = encoder.embed_utterance(wav)

# Compare voices (cosine similarity)
similarity = np.dot(saved_embedding, new_embedding)

print(f"🔎 Similarity score: {similarity:.2f}")

# Decision
THRESHOLD = 0.75

if similarity >= THRESHOLD:
    print("✅ Authorized voice (same person)")
else:
    print("❌ Unauthorized voice (different person)")
